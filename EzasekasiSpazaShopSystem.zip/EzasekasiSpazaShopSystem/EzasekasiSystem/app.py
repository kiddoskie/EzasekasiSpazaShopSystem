from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'tut_secret_key_2026' 

# --- 1. DATABASE CONNECTION ---
def get_db_connection():
    try:
        return mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="TalentBridge2026!",
            database="ezasekasi_db",
            auth_plugin='mysql_native_password'
        )
    except mysql.connector.Error as err:
        print(f"DATABASE ERROR: {err}")
        return None

# --- 2. SECURITY WRAPPERS (Assessment 4 Security Hierarchy) ---

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            flash("Please login to access this page.", "danger")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def owner_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('role') != 'Owner':
            flash("Access Denied: Restricted to Shop Owner only.", "danger")
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def management_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Allows Mercy (Owner), Happiness (Admin), and Mapule (Admin)
        if session.get('role') not in ['Owner', 'Admin']:
            flash("Access Denied: Requires Admin or Management rights.", "danger")
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# --- 3. AUTHENTICATION ---

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Users WHERE username = %s AND password_hash = %s", (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['logged_in'] = True
            session['user_id'] = user['user_id']
            session['role'] = user['user_role']
            session['username'] = user['full_name']
            flash(f"Welcome back, {user['full_name']}!", "success")
            return redirect(url_for('index'))
        else:
            # THIS IS THE ERROR TRIGGER
            flash("Login Failed: Incorrect username or password. Please try again.", "danger")
            return redirect(url_for('login'))
            
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
@login_required
@owner_required 
def register():
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True) # dictionary=True makes it easier for Jinja
    
    if request.method == 'POST':
        full_name = request.form['full_name']
        username = request.form['username']
        password = request.form['password']
        role = request.form['user_role'] # Matches the updated HTML select name
        
        try:
            cur.execute("SELECT * FROM Users WHERE username = %s", (username,))
            if cur.fetchone():
                flash("Username already exists!", "danger")
            else:
                cur.execute("INSERT INTO Users (full_name, username, password_hash, user_role) VALUES (%s, %s, %s, %s)", 
                           (full_name, username, password, role))
                conn.commit()
                flash("User recorded successfully!", "success")
        except Exception as e:
            flash(f"Error: {str(e)}", "danger")

    # Fetch ALL users so the directory table is always up to date
    cur.execute("SELECT * FROM Users")
    all_users = cur.fetchall()
    conn.close()
    
    return render_template('register.html', title="User Management", users_list=all_users)
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# --- 4. NAVIGATION & MULTI-TABLE REPORTS ---

@app.route('/')
@login_required
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Products")
    products = cursor.fetchall()
    cursor.execute("SELECT final_score FROM Credit_Scores WHERE user_id = %s", (session['user_id'],))
    score_row = cursor.fetchone()
    conn.close()
    
    current_score = score_row['final_score'] if score_row else 845
    return render_template('dashboard.html', products=products, title="Main Dashboard", credit_score=current_score)

@app.route('/credit')
@login_required
@owner_required # Mercy's specialized AI Module
def credit():
    today = datetime.now()
    default_start = today.replace(day=1).strftime('%Y-%m-%d')
    default_end = today.strftime('%Y-%m-%d')
    
    start_date = request.args.get('start_date', default_start)
    end_date = request.args.get('end_date', default_end)

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    
    # Report: Displays data from Credit_Scores JOINED with Users (Assessment 4 Requirement)
    query = """
        SELECT cs.*, u.full_name 
        FROM Credit_Scores cs 
        JOIN Users u ON cs.user_id = u.user_id 
        WHERE cs.last_updated BETWEEN %s AND %s
    """
    cur.execute(query, (start_date, end_date))
    report_data = cur.fetchall()

    # Individual Logic: AI formula based on DB Audit
    cur.execute("SELECT SUM(total_amount) as total_revenue FROM Sales")
    rev = cur.fetchone()['total_revenue'] or 0
    cur.execute("SELECT COUNT(*) as total_items FROM Products")
    items = cur.fetchone()['total_items'] or 0
    final_ai_score = int(min(max((float(rev) * 0.7) + (items * 15), 300), 1000))
    
    conn.close()
    return render_template('credit.html', title="AI Credit Intelligence", report=report_data, 
                           start_date=start_date, end_date=end_date, credit_score=final_ai_score)

@app.route('/inventory')
@login_required
@management_required # Protects Mapule/Kearabetswe's module from Cashiers
def inventory():
    return render_template('inventory.html', title="Inventory Manager")

@app.route('/sales')
@login_required
def sales():
    # Restricted to operational roles (Mercy, Karabo, Happiness, Kearabetswe)
    if session.get('role') not in ['Cashier', 'Admin', 'Owner']:
        flash("You do not have permission to access the POS system.", "danger")
        return redirect(url_for('index'))
        
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Products")
    products = cursor.fetchall()
    conn.close()
    return render_template('sales.html', products=products, title="Sales & POS")

# --- 5. DML OPERATIONS & ERROR HANDLING ---

@app.route('/update_stock/<int:product_id>', methods=['POST'])
@login_required
@management_required
def update_stock(product_id):
    added_qty = request.form.get('added_quantity')
    
    # Page-level validation (Requirement: Individual Error Handling marks)
    if not added_qty or int(added_qty) <= 0:
        flash("Update failed: Quantity must be greater than 0.", "danger")
        return redirect(url_for('index'))

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE Products SET stock_quantity = stock_quantity + %s WHERE product_id = %s", (added_qty, product_id))
        conn.commit()
        flash("Stock updated successfully!", "success")
    except Exception as e:
        flash(f"Error: {str(e)}", "danger")
    finally:
        conn.close()
    return redirect(url_for('index'))

@app.route('/process_sale', methods=['POST'])
@login_required
def process_sale():
    product_id = request.form['product_id']
    qty = int(request.form['qty'])
    sale_date = request.form['sale_date']
    is_bulk = 1 if request.form.get('is_bulk') else 0
    
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT selling_price, stock_quantity FROM Products WHERE product_id = %s", [product_id])
    product = cur.fetchone()
    
    if product and product['stock_quantity'] >= qty:
        total_amount = product['selling_price'] * qty
        cur.execute("""
            INSERT INTO Sales (product_id, user_id, quantity_sold, total_amount, manual_sale_date, is_bulk_sale) 
            VALUES (%s, %s, %s, %s, %s, %s)""", 
            (product_id, session['user_id'], qty, total_amount, sale_date, is_bulk))
        cur.execute("UPDATE Products SET stock_quantity = stock_quantity - %s WHERE product_id = %s", (qty, product_id))
        conn.commit()
        flash("Transaction Successful!", "success")
    else:
        flash("Transaction Failed: Insufficient stock!", "danger")
    
    conn.close()
    return redirect(url_for('index'))

@app.route('/add_product', methods=['POST'])
@login_required
@management_required
def add_product():
    name = request.form['product_name']
    category = request.form['category']
    cost = request.form['cost_price'] 
    selling = request.form['selling_price']
    stock = request.form['stock_level'] 
    supplier = request.form['supplier_id']
    
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            INSERT INTO Products (product_name, category, cost_price, selling_price, stock_quantity, supplier_id) 
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (name, category, cost, selling, stock, supplier))
        conn.commit()
        flash("New product added to inventory!", "success")
    except Exception as e:
        flash(f"Database Error: {str(e)}", "danger")
    finally:
        conn.close()
    return redirect(url_for('inventory'))
# --- 6. ADDITIONAL TEAM REPORTS (Assessment 4: 1 per member) ---

# Report 1: Sales Performance (Karabo's Report)
# Joins Sales and Products to show business value 
@app.route('/report_sales')
@login_required
@management_required
def report_sales():
    # Capture the filter value from the URL
    category_filter = request.args.get('category', '')

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    
    # Base Query
    query = "SELECT s.*, p.product_name, p.category FROM Sales s JOIN Products p ON s.product_id = p.product_id"
    params = []

    # Apply Filtering Logic (DML Integrity Requirement)
    if category_filter:
        query += " WHERE p.category = %s"
        params.append(category_filter)
    
    query += " ORDER BY s.sale_timestamp DESC"
    
    cur.execute(query, params)
    sales_data = cur.fetchall()
    conn.close()
    
    return render_template('report_sales.html', data=sales_data, selected_category=category_filter)

# Report 2: Inventory Status (Mapule's Report)
# Joins Products and Suppliers to show reorder needs 
@app.route('/report_inventory')
@login_required
@management_required
def report_inventory():
    # Capture the supplier name filter from the URL
    supplier_filter = request.args.get('supplier_name', '')

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    
    # Base Query: Joins Products and Suppliers (Requirement: Multi-table data)
    query = """
        SELECT p.*, s.company_name, s.contact_person 
        FROM Products p 
        LEFT JOIN Suppliers s ON p.supplier_id = s.supplier_id
    """
    params = []

    # Apply Filtering Logic (DML Integrity Requirement)
    if supplier_filter:
        query += " WHERE s.company_name = %s"
        params.append(supplier_filter)
    
    query += " ORDER BY p.stock_quantity ASC"
    
    cur.execute(query, params)
    inventory_data = cur.fetchall()

    # Fetch suppliers for the dropdown list
    cur.execute("SELECT DISTINCT company_name FROM Suppliers")
    suppliers_list = cur.fetchall()
    
    conn.close()
    
    return render_template('report_inventory.html', 
                           title="Low Stock Audit", 
                           data=inventory_data, 
                           suppliers=suppliers_list,
                           selected_supplier=supplier_filter)
# Report 3: Supplier Delivery Log (Kearabetswe's Report)
# Joins Products and Suppliers to track stock origins 
@app.route('/report_suppliers')
@login_required
@management_required
def report_suppliers():
    # Capture the search term from the URL
    search_query = request.args.get('search', '')

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    
    # Base Query: Joins Suppliers and Products
    query = """
        SELECT s.company_name, p.product_name, p.stock_quantity, p.category
        FROM Suppliers s
        JOIN Products p ON s.supplier_id = p.supplier_id
    """
    params = []

    # Apply Filtering Logic
    if search_query:
        query += " WHERE s.company_name LIKE %s OR p.category LIKE %s"
        params.append(f"%{search_query}%")
        params.append(f"%{search_query}%")
    
    query += " ORDER BY s.company_name ASC"
    
    cur.execute(query, params)
    supplier_data = cur.fetchall()
    conn.close()
    
    return render_template('report_suppliers.html', 
                           title="Supplier Distribution", 
                           data=supplier_data, 
                           search_term=search_query)

# --- DELETE PRODUCT (Mapule/Kearabetswe) ---
@app.route('/delete_product/<int:product_id>')
@login_required
@management_required
def delete_product(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Attempt to delete
        cursor.execute("DELETE FROM Products WHERE product_id = %s", (product_id,))
        conn.commit()
        flash("Product removed successfully.", "success")
    except mysql.connector.Error as err:
        # This triggers if there are Sales records linked to this Product
        flash("Cannot delete product: It is linked to existing sales records. Try updating stock to 0 instead.", "danger")
    finally:
        conn.close()
    return redirect(url_for('index'))

# --- DELETE USER (Mercy/Owner only) ---
@app.route('/delete_user/<int:user_id>')
@login_required
@owner_required
def delete_user(user_id):
    # Prevent the owner from deleting themselves!
    if user_id == session.get('user_id'):
        flash("Action denied: You cannot delete your own account.", "danger")
        return redirect(url_for('register'))

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM Users WHERE user_id = %s", (user_id,))
        conn.commit()
        flash("Staff member removed from system.", "success")
    except Exception as e:
        flash("Error: This user is linked to sales transactions.", "danger")
    finally:
        conn.close()
    return redirect(url_for('register'))

@app.route('/update_user_role/<int:user_id>', methods=['POST'])
@login_required
@owner_required
def update_user_role(user_id):
    new_role = request.form.get('new_role')
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE Users SET user_role = %s WHERE user_id = %s", (new_role, user_id))
        conn.commit()
        flash("Staff role updated successfully!", "success")
    except Exception as e:
        flash(f"Error: {str(e)}", "danger")
    finally:
        conn.close()
    return redirect(url_for('register'))

@app.errorhandler(404)
def page_not_found(e):
    # Professional error handling at server level
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    # Lowest possible level handling to prevent system crash
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)