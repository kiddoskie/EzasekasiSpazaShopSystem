-- ==========================================
-- ASSESSMENT 3: FULL DATABASE SCHEMA (FINAL VERIFIED)
-- Project: Ezasekasi Spaza Shop System
-- Group: Mercy, Karabo, Happiness, Mapule, Kearabetswe
-- ==========================================

CREATE DATABASE IF NOT EXISTS ezasekasi_db;
USE ezasekasi_db;

-- DROP TABLES IN CORRECT ORDER
DROP TABLE IF EXISTS AI_Predictions;
DROP TABLE IF EXISTS Credit_Scores;
DROP TABLE IF EXISTS Sales;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Users;
DROP TABLE IF EXISTS Suppliers;

-- 1. USERS TABLE
CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    user_role ENUM('Owner', 'Cashier', 'Supplier', 'Admin') NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    contact_number VARCHAR(15)
);

-- 2. SUPPLIERS TABLE
CREATE TABLE Suppliers (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(15),
    email VARCHAR(100)
);

-- 3. PRODUCTS TABLE (Mapule/Kearabetswe)
CREATE TABLE Products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100) UNIQUE NOT NULL, 
    category VARCHAR(50),
    cost_price DECIMAL(10, 2) DEFAULT 0.00,
    selling_price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    reorder_level INT DEFAULT 5,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id) ON DELETE SET NULL
);

-- 4. SALES TABLE (Karabo/Happiness)
CREATE TABLE Sales (
    sale_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    user_id INT, 
    quantity_sold INT NOT NULL,
    total_amount DECIMAL(10, 2),
    sale_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    manual_sale_date DATE, 
    is_bulk_sale TINYINT(1) DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES Products(product_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- 5. CREDIT_SCORES TABLE (Mercy - AI Integration)
-- IMPROVED: Scores changed to DECIMAL for precision auditing
CREATE TABLE Credit_Scores (
    score_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE, 
    consistency_score DECIMAL(5,2) DEFAULT 0.00, 
    volume_score DECIMAL(5,2) DEFAULT 0.00,      
    growth_score DECIMAL(5,2) DEFAULT 0.00,      
    final_score INT DEFAULT 300,       
    approval_status ENUM('Approved', 'Pending', 'Declined') DEFAULT 'Pending', 
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- 6. AI_PREDICTIONS TABLE 
CREATE TABLE AI_Predictions (
    prediction_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    prediction_type ENUM('Demand', 'Trend', 'Theft Alert'),
    confidence_level DECIMAL(5, 2), 
    predicted_value VARCHAR(100),
    prediction_date DATE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- ==========================================
-- POPULATING DATA
-- ==========================================

INSERT INTO Users (full_name, user_role, username, password_hash) VALUES 
('Mercy Molonyama', 'Owner', 'mercy_m', '123456'),
('Happiness Simao', 'Owner', 'happy_s', '123456'),
('Brightness Masilela', 'Owner', 'bri_m', '123456'),
('Keabetswe Lebelo', 'Owner', 'kea_l', '123456'),
('Karabo Komane', 'Owner', 'kaybee_k', '123456');

INSERT INTO Suppliers (company_name, contact_person, phone) VALUES 
('Tshwane Wholesalers', 'Mr. Dube', '0125550001'),
('Emalahleni Bakery', 'Sarah', '0135559999'),
('Beverage Corp', 'John', '0114441111'),
('Dairy Fresh', 'Lerato', '0127778888'),
('Agri-Nathi Logistics', 'Thabo', '0153332222');

-- Products populate with cost price (needed for AI margin calculation)
INSERT INTO Products (product_name, category, cost_price, selling_price, stock_quantity, supplier_id) VALUES 
('Milk 2L', 'Dairy', 28.00, 35.00, 20, 4),
('Brown Bread', 'Bakery', 12.00, 18.50, 15, 2),
('Sugar 2kg', 'Pantry', 38.00, 48.00, 10, 1),
('Coke 500ml', 'Beverage', 9.50, 15.00, 50, 3),
('Eggs 12pk', 'Dairy', 24.00, 32.00, 12, 4);

-- Initial AI baseline for the Shop Owner (Mercy)
INSERT INTO Credit_Scores (user_id, consistency_score, volume_score, final_score, approval_status) 
VALUES (1, 85.50, 78.20, 818, 'Approved');